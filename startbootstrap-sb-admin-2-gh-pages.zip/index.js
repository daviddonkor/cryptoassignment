const express = require('express');
const bodyParser= require('body-parser');
const sqlite3 = require('sqlite3').verbose();
const app=express();
const port=4000;

app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(__dirname  + '/public'));

//Db Connnection, Can be moved to the routes to prevent loading DB when it is not needed. 
//This is just for assignment purposes
const db =new sqlite3.Database('./db/myCryptoBank.db',sqlite3.OPEN_READWRITE,(err)=>{
    if(err){
        console.error(err.message)
    }
    console.log("Connected to the Transactions DB");
});

//Set the EJS engine
app.set("view engine",'ejs');

//Home Route
app.get('/', (req,res)=>{
    res.render("pages/index");
})

//Buy Crypto Route
app.get('/buyCrypto', (req,res)=>{
    res.render("pages/buycrypto");
});

//Post buy Crypto Route
app.post('/buyCrypto', (req,res)=>{

    // Getting the last current value
   
    var mlast;
    db.all("select current_balance from transactions where currency='"+req.body.coin+"'\
     ORDER BY id DESC LIMIT 1",[],function(err,rows){
        if(err){
            console.error(err.message);
        }
    
        rows.forEach(function(row){
            
          return parseFloat(row.current_balance);
        });
    });

    console.log(mlast);
    currentbalance=parseFloat(req.body.amount)+parseFloat(mlast);
    db.run('INSERT INTO transactions(time,currency,amount_purchased,current_balance) VALUES(?, ?, ?, ?)',[
        Date.now(),
        req.body.coin,
        req.body.amount,
        currentbalance
    ],function(err){
        if(err){
            res.send(err.message)
        }
        res.redirect("/transactions");
    });

})

app.get('/transactions', (req,res)=>{
    
        const db =new sqlite3.Database('./db/myCryptoBank.db',sqlite3.OPEN_READWRITE,(err)=>{
                if(err){
                    console.error(err.message)
                }
                console.log("Connected to the Transactions DB");
            });

            db.all("select * from transactions",[],(err,rows)=>{
                if(err){
                    console.error(err.message);
                }
                res.render("pages/transactions",{transactions:rows.sort(function(a,b){
                    return b.time-a.time;
                })}); 
            });
            db.close();
        console.log("no data found");
         
});



app.listen(port,()=>{
console.log("Server starting at port 4000");
});